<?php

class Complaint {

    private ?string $request_type;
    private ?string $status;
    private ?int $id;
    private ?string $full_name;
    private ?string $nationality;
    private ?string $email;
    private ?string $phone_number;
    private ?string $address;
    private ?int $stay_duration;
    private ?string $description;
    private ?string $resolution;

    // Constructor
    public function __construct(
        ?string $request_type,
        ?string $status,
        ?int $id,
        ?string $full_name,
        ?string $nationality,
        ?string $email,
        ?string $phone_number,
        ?string $address,
        ?int $stay_duration,
        ?string $description,
        ?string $resolution = null
    ) {
        $this->request_type = $request_type;
        $this->status = $status;
        $this->id = $id;
        $this->full_name = $full_name;
        $this->nationality = $nationality;
        $this->email = $email;
        $this->phone_number = $phone_number;
        $this->address = $address;
        $this->stay_duration = $stay_duration;
        $this->description = $description;
        $this->resolution = $resolution;
    }

    // Getters and Setters
    public function getRequestType(): ?string {
        return $this->request_type;
    }

    public function setRequestType(?string $request_type): void {
        $this->request_type = $request_type;
    }

    public function getStatus(): ?string {
        return $this->status;
    }

    public function setStatus(?string $status): void {
        $this->status = $status;
    }

    public function getId(): ?int {
        return $this->id;
    }

    public function setId(?int $id): void {
        $this->id = $id;
    }

    public function getFullName(): ?string {
        return $this->full_name;
    }

    public function setFullName(?string $full_name): void {
        $this->full_name = $full_name;
    }

    public function getNationality(): ?string {
        return $this->nationality;
    }

    public function setNationality(?string $nationality): void {
        $this->nationality = $nationality;
    }

    public function getEmail(): ?string {
        return $this->email;
    }

    public function setEmail(?string $email): void {
        $this->email = $email;
    }

    public function getPhoneNumber(): ?string {
        return $this->phone_number;
    }

    public function setPhoneNumber(?string $phone_number): void {
        $this->phone_number = $phone_number;
    }

    public function getAddress(): ?string {
        return $this->address;
    }

    public function setAddress(?string $address): void {
        $this->address = $address;
    }

    public function getStayDuration(): ?int {
        return $this->stay_duration;
    }

    public function setStayDuration(?int $stay_duration): void {
        $this->stay_duration = $stay_duration;
    }

    public function getDescription(): ?string {
        return $this->description;
    }

    public function setDescription(?string $description): void {
        $this->description = $description;
    }

    public function getResolution(): ?string {
        return $this->resolution;
    }

    public function setResolution(?string $resolution): void {
        $this->resolution = $resolution;
    }
}

?>
