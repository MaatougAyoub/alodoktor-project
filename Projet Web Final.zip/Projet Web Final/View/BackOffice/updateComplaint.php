<?php

include '../../Controller/ComplaintController.php';


$error = "";

$complaint= null;
// create an instance of the controller
$ComplaintC = new ComplaintController();


if (
    isset($_POST["request_type"], $_POST["status"], $_POST["full_name"], $_POST["nationality"],
          $_POST["email"], $_POST["phone_number"], $_POST["address"],
          $_POST["stay_duration"], $_POST["description"])
) {
    if (
        !empty($_POST["request_type"]) && !empty($_POST["status"]) &&
        !empty($_POST["full_name"]) && !empty($_POST["nationality"]) &&
        !empty($_POST["email"]) && !empty($_POST["phone_number"]) &&
        !empty($_POST["address"]) && !empty($_POST["stay_duration"]) &&
        !empty($_POST["description"])
    ) {
        $resolution = isset($_POST['resolution']) ? $_POST['resolution'] : null;

        $complaint = new Complaint(
            $_POST["request_type"],
            $_POST["status"],
            null,
            $_POST["full_name"],
            $_POST["nationality"],
            $_POST["email"],
            $_POST["phone_number"],
            $_POST["address"],
            intval($_POST["stay_duration"]),
            $_POST["description"],
            $resolution
        );

        $complaintController->updateComplaint($complaint, $_POST);
        header('Location:complaintList.php');
        exit();
    } else {
        $error = "Missing information";
    }
}

?>
<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
    
        <title>Update Complaints & Claims - Dashboard</title>
    
        <!-- Custom fonts for this template-->
        <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
        <link
            href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
            rel="stylesheet">
    
        <!-- Custom styles for this template-->
        <link href="css/sb-admin-2.min.css" rel="stylesheet">
    
    </head>
    <body id="page-top">

        <!-- Page Wrapper -->
        <div id="wrapper">
    
            <!-- Sidebar -->
            <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    
                <!-- Sidebar - Brand -->
                <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                    
                    <div class="sidebar-brand-text mx-3">Complaints & Claims <sup></sup></div>
                </a>
    
                <!-- Divider -->
                <hr class="sidebar-divider my-0">
    
                <!-- Nav Item - Dashboard -->
                <li class="nav-item active">
                    <a class="nav-link" href="#">
                        <i class="fas fa-fw fa-tachometer-alt"></i>
                        <span>Dashboard</span></a>
                </li>
                
    
                <li class="nav-item active">
                    <a class="nav-link" href="offerList.php">
                        <i class="fas fa-fw fa-tachometer-alt"></i>
                        <span>Back to Complaints & Claims List</span></a>
                </li>
    
    
            </ul>
            <!-- End of Sidebar -->
    
            <!-- Content Wrapper -->
            <div id="content-wrapper" class="d-flex flex-column">
    
                <!-- Main Content -->
                <div id="content">
    
                    <!-- Topbar -->
                    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    
                        <!-- Sidebar Toggle (Topbar) -->
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
    
                    </nav>
                    <!-- End of Topbar -->
    
                    <!-- Begin Page Content -->
                    <div class="container-fluid">
    
                        <!-- Page Heading -->
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Update the Complaints & Claims with Id = <?php echo $_POST['id'] ?> </h1>
                                  </div>
    
                        <!-- Content Row -->
                        <div class="row">
    
                            <!-- Earnings (Monthly) Card Example -->
                            <div class="col-xl-12 col-md-6 mb-4">
                                <div class="card border-left-primary shadow h-100 py-2">
                                    <div class="card-body">
                                        <div class="row no-gutters align-items-center">
                                        <?php
    if (isset($_POST['id'])) {
        $complaint = $ComplaintController->showComplaint($_POST['id']);
       
    ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>

    <form id="updateComplaintForm" method="POST">
        <label for="request_type">Request Type:</label>
        <select class="form-controlform-control-user"  name="request_type" id="request_type"><br>
            <option value="complain">Complaint</option>
            <option value="claim">Claim</option>
        </select>
        <span id="request_type_error"></span><br>

        <label for="status">Status:</label><br>
        <select class="form-control form-control-user" name="status" id="status" >
            <option value="patient">Patient</option>
            <option value="relative">Relative</option>
            <option value="staff">Staff</option>
            <option value="doctor">Docteur</option>
            <option value="legal_representative">Legal Representative</option>
            <option value="other">Other</option>
        </select>
        <span id="status_error"></span><br>

        <label for="full_name">Full Name:</label><br>
        <input class="form-control" type="text" name="full_name" id="full_name"><br>
        <span id="full_name_error"></span><br>

        <label for="nationality">Nationality:</label><br>
        <input class="form-control" type="text" name="nationality" id="nationality"><br>
        <span id="nationality_error"></span><br>

        <label for="email">Email:</label><br>
        <input class="form-control" type="email" name="email" id="email"><br>
        <span id="email_error"></span><br>

        <label for="phone_number">Phone Number:</label><br>
        <input class="form-control" type="text" name="phone_number" id="phone_number"><br>
        <span id="phone_number_error"></span><br>

        <label for="address">Address:</label><br>
        <input class="form-control" type="text" name="address" id="address"><br>
        <span id="address_error"></span><br>

        <label for="stay_duration">Stay Duration (days):</label><br>
        <input class="form-control" type="number" name="stay_duration" id="stay_duration"><br>
        <span id="stay_duration_error"></span><br>

        <label for="description">Description:</label><br>
        <textarea class="form-control" name="description" id="description"pattern="[A-Za-zÀ-ÿ\s\-']{200,}" required placeholder="Décrivez votre plainte ou réclamation"></textarea>></textarea><br>
        <span id="description_error"></span><br>

        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <label for="resolution">Resolution :</label><br>
        <textarea class="form-control" name="resolution" id="resolution" ></textarea><br>
        <?php endif; ?>

        <button class="btn btn-primary btn-user btn-block" type="submit" onClick="validerFormulaire()">Add Complaint</button>
        <div id="confirmation-message" style="display: none; color: green; font-weight: bold; margin-bottom: 20px;">
            Your complaint or claim has been successfully submitted!
        </div> 
    </form>
                                            <?php
    }
    ?>
                                        </div>
                                    </div>
                                </div>
                            </div> 
                        </div>
                    </div>
                </div>
               
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                        <div class="copyright text-center my-auto">
                            <span>Copyright &copy; Travel Booking 2024</span>
                        </div>
                    </div>
                </footer>
            </div>
        </div>

        <footer class="footer">
            <div class="access-page">
                <div class="access-plan">
                    <h4>ACCESS PLAN</h4>
                    <iframe class="carte" src="https://www.google.com/maps/embed?..." width="600" height="450" style="border:0;" allowfullscreen loading="lazy"></iframe>
                </div>
                <div class="useful-links">
                    <h4>USEFUL LINKS</h4>
                    <p>Consultations & Calls</p>
                    <p>for tenders</p>
                    <p>Site map</p>
                    <p>Access to information</p>
                </div>
                <div class="contact">
                    <h4>CONTACT</h4>
                    <p>Avenue de la Rébublique Bp 77-1054 Amilcar</p>
                    <p><a href="mailto:alodoktor@gmail.com">alodoktor@gmail.com</a></p>
                    <p>+216 99 999 999 | +216 71 234 567</p>
                    <p><a href="https://www.facebook.com/">Facebook</a></p>
                    <p><a href="https://www.instagram.com/">Instagram</a></p>
                    <p><a href="https://www.x.com/">X</a></p>
                    <p><a href="https://www.linkedin.com/">Linkedin</a></p>
                </div>
            </div>
            <div class="copyright-page">
                <p>&copy; AloDoktor 2025 - Privacy Policy Legal Notice</p>
            </div>
        </footer>
       
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>
        <script src="js/addComplaint.js"></script>
    
        <!-- Bootstrap core JavaScript-->
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    
        <!-- Core plugin JavaScript-->
        <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    
        <!-- Custom scripts for all pages-->
        <script src="js/sb-admin-2.min.js"></script>
    
        <!-- Page level plugins -->
        <script src="vendor/chart.js/Chart.min.js"></script>
    
        <!-- Page level custom scripts -->
        <script src="js/demo/chart-area-demo.js"></script>
        <script src="js/demo/chart-pie-demo.js"></script>
    
    </body>

</html>
