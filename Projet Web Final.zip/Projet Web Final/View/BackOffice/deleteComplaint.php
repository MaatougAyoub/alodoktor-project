<?php
include '../../Controller/ComplaintController.php';
$ComplaintC = new ComplaintController();
$ComplaintC->deleteComplaint($_GET["id"]);
header('Location:ComplaintList.php');
?>