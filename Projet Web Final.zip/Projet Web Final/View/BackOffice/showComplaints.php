<?php
include '../../Model/Complaint.php';

// Création d'une plainte avec des données d'exemple
$complaint = new Complaint(
    'complain',                // request_type
    'patient',                 // status
    1,                          // ID
    'Jane Doe',                // full_name
    'French',                  // nationality
    'jane@example.com',        // email
    '+33123456789',            // phone_number
    '12 rue de Paris, France', // address
    5,                         // stay_duration
    'Service médical inacceptable.', // description
    'Offre de rendez-vous de suivi et excuses officielles.' // resolution
);
var_dump($Complaint);
echo "<br><hr><br>";
$Complaint->show();
?>
