<?php
include '../../Controller/ComplaintController.php';
$ComplaintC = new ComplaintController();
$list = $ComplaintC->listComplaints();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Complaint List - Dashboard</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body id="page-top">
<div id="wrapper">
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
            <div class="sidebar-brand-text mx-3">Complaints & Claims</div>
        </a>
        <hr class="sidebar-divider my-0">
        <li class="nav-item active">
            <a class="nav-link" href="#">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>
        <li class="nav-item active">
            <a class="nav-link" href="addComplaint.php">
                <i class="fas fa-fw fa-plus"></i>
                <span>Add Complaint or Claim</span></a>
        </li>
    </ul>
    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>
            </nav>
            <div class="container-fluid">
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Complaints & Claims List</h1>
                </div>
                <div class="row">
                    <div class="col-xl-12 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Request Type</th>
                                                <th>Status</th>
                                                <th>Full Name</th>
                                                <th>Nationality</th>
                                                <th>Email</th>
                                                <th>Phone Number</th>
                                                <th>Address</th>
                                                <th>Stay Duration</th>
                                                <th>Description</th>
                                                <th>Resolution</th>
                                                <th colspan="2">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($list as $complaint): ?>
                                            <tr>
                                                <td><?= $complaint['id']; ?></td>
                                                <td><?= $complaint['request_type']; ?></td>
                                                <td><?= $complaint['status']; ?></td>
                                                <td><?= $complaint['full_name']; ?></td>
                                                <td><?= $complaint['nationality']; ?></td>
                                                <td><?= $complaint['email']; ?></td>
                                                <td><?= $complaint['phone_number']; ?></td>
                                                <td><?= $complaint['address']; ?></td>
                                                <td><?= $complaint['stay_duration']; ?></td>
                                                <td><?= $complaint['description']; ?></td>
                                                <td><?= $complaint['resolution']; ?></td>
                                                <td>
                                                    <form method="POST" action="updateComplaint.php">
                                                        <input type="hidden" name="id" value="<?= $complaint['id']; ?>">
                                                        <input type="submit" name="update" value="Update">
                                                    </form>
                                                </td>
                                                <td>
                                                    <a href="deleteComplaint.php?id=<?= $complaint['id']; ?>">Delete</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<footer class="footer">
    <div class="access-page">
        <div class="access-plan">
            <h4>ACCESS PLAN</h4>
            <iframe class="carte" src="https://www.google.com/maps/embed?..." width="600" height="450" style="border:0;" allowfullscreen loading="lazy"></iframe>
        </div>
        <div class="useful-links">
            <h4>USEFUL LINKS</h4>
            <p>Consultations & Calls</p>
            <p>for tenders</p>
            <p>Site map</p>
            <p>Access to information</p>
        </div>
        <div class="contact">
            <h4>CONTACT</h4>
            <p>Avenue de la Rébublique Bp 77-1054 Amilcar</p>
            <p><a href="mailto:alodoktor@gmail.com">alodoktor@gmail.com</a></p>
            <p>+216 99 999 999 | +216 71 234 567</p>
            <p><a href="https://www.facebook.com/">Facebook</a></p>
            <p><a href="https://www.instagram.com/">Instagram</a></p>
            <p><a href="https://www.x.com/">X</a></p>
            <p><a href="https://www.linkedin.com/">Linkedin</a></p>
        </div>
    </div>
    <div class="copyright-page">
        <p>&copy; AloDoktor 2025 - Privacy Policy Legal Notice</p>
    </div>
</footer>
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="js/sb-admin-2.min.js"></script>
<script src="vendor/chart.js/Chart.min.js"></script>
<script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script>
</body>
</html>