document.addEventListener("DOMContentLoaded", function () {
    const fullName = document.getElementById("full_name");
    const nationality = document.getElementById("nationality");
    const email = document.getElementById("email");
    const phone = document.getElementById("phone_number");
    const address = document.getElementById("address");
    const stayDuration = document.getElementById("stay_duration");
    const description = document.getElementById("description");

    // Full Name validation
    fullName.addEventListener("keyup", function () {
        const error = document.getElementById("full_name_error");
        if (fullName.value.length < 3) {
            error.innerText = "Full name must be at least 3 characters long";
            error.style.color = "red";
        } else {
            error.innerText = "Valid";
            error.style.color = "green";
        }
    });

    // Nationality validation
    nationality.addEventListener("keyup", function () {
        const error = document.getElementById("nationality_error");
        const pattern = /^[A-Za-z\s]{3,}$/;
        if (!pattern.test(nationality.value)) {
            error.innerText = "Nationality must contain only letters and be at least 3 characters";
            error.style.color = "red";
        } else {
            error.innerText = "Valid";
            error.style.color = "green";
        }
    });

    // Email validation
    email.addEventListener("keyup", function () {
        const error = document.getElementById("email_error");
        const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!pattern.test(email.value)) {
            error.innerText = "Invalid email address";
            error.style.color = "red";
        } else {
            error.innerText = "Valid";
            error.style.color = "green";
        }
    });

    // Phone number validation
    phone.addEventListener("keyup", function () {
        const error = document.getElementById("phone_error");
        const pattern = /^216[0-9]{8}$/;
        if (!pattern.test(phone.value)) {
            error.innerText = "Phone number must start with 216 and contain 12 digits in total";
            error.style.color = "red";
        } else {
            error.innerText = "Valid";
            error.style.color = "green";
        }
    });

    // Address validation
    address.addEventListener("keyup", function () {
        const error = document.getElementById("address_error");
        if (address.value.length < 5) {
            error.innerText = "Address is too short";
            error.style.color = "red";
        } else {
            error.innerText = "Valid";
            error.style.color = "green";
        }
    });

    // Stay duration validation
    stayDuration.addEventListener("keyup", function () {
        const error = document.getElementById("stay_duration_error");
        if (isNaN(stayDuration.value) || parseInt(stayDuration.value) <= 0) {
            error.innerText = "Please enter a valid number greater than 0";
            error.style.color = "red";
        } else {
            error.innerText = "Valid";
            error.style.color = "green";
        }
    });

    // Description validation
    description.addEventListener("keyup", function () {
        const error = document.getElementById("description_error");
        if (description.value.length < 200) {
            error.innerText = "Description must be at least 200 characters long";
            error.style.color = "red";
        } else {
            error.innerText = "Valid";
            error.style.color = "green";
        }
    });
});
