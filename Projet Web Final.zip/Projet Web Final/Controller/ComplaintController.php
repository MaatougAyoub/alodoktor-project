<?php
include(__DIR__ . '/../config.php');
include(__DIR__ . '/../Model/Complaint.php');

class ComplaintController
{
    public function listComplaints()
    {
        $sql = "SELECT * FROM complaints";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }

    function addComplaint($complaint)
    {
        $sql = "INSERT INTO complaints (request_type, status, full_name, nationality, email, phone_number, address, stay_duration, description, resolution)
                VALUES (:request_type, :status, :full_name, :nationality, :email, :phone_number, :address, :stay_duration, :description, :resolution)";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute([
                'request_type' => $complaint->getRequestType(),
                'status' => $complaint->getStatus(),
                'full_name' => $complaint->getFullName(),
                'nationality' => $complaint->getNationality(),
                'email' => $complaint->getEmail(),
                'phone_number' => $complaint->getPhoneNumber(),
                'address' => $complaint->getAddress(),
                'stay_duration' => $complaint->getStayDuration(),
                'description' => $complaint->getDescription(),
                'resolution' => $complaint->getResolution()
            ]);
        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }

    function updateComplaint($complaint, $id)
    {
        try {
            $db = config::getConnexion();

            $query = $db->prepare(
                'UPDATE complaints SET 
                    request_type = :request_type,
                    status = :status,
                    full_name = :full_name,
                    nationality = :nationality,
                    email = :email,
                    phone_number = :phone_number,
                    address = :address,
                    stay_duration = :stay_duration,
                    description = :description,
                    resolution = :resolution
                WHERE id = :id'
            );

            $query->execute([
                'id' => $id,
                'request_type' => $complaint->getRequestType(),
                'status' => $complaint->getStatus(),
                'full_name' => $complaint->getFullName(),
                'nationality' => $complaint->getNationality(),
                'email' => $complaint->getEmail(),
                'phone_number' => $complaint->getPhoneNumber(),
                'address' => $complaint->getAddress(),
                'stay_duration' => $complaint->getStayDuration(),
                'description' => $complaint->getDescription(),
                'resolution' => $complaint->getResolution()
            ]);

            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    function deleteComplaint($id)
    {
        $sql = "DELETE FROM complaints WHERE id = :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);

        try {
            $req->execute();
        } catch (Exception $e) {
            die('Error:' . $e->getMessage());
        }
    }

    function showComplaint($id)
    {
        $sql = "SELECT * FROM complaints WHERE id = :id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->bindParam(':id', $id);
            $query->execute();

            $complaint = $query->fetch();
            return $complaint;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
}
?>