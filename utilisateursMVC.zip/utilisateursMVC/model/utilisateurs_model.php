<?php

class Utilisateur {
    private ?string $nom;
    private ?string $prenom;
    private ?string $email;
    private ?DateTime $date_naissance;
    private ?string $lieu_naissance;
    private ?string $sexe;
    private ?string $mot_de_passe;

    // Constructor
    public function __construct(?string $nom, ?string $prenom, ?string $email, ?DateTime $date_naissance, ?string $lieu_naissance, ?string $sexe, ?string $mot_de_passe) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->email = $email;
        $this->date_naissance = $date_naissance;
        $this->lieu_naissance = $lieu_naissance;
        $this->sexe = $sexe;
        $this->mot_de_passe = $mot_de_passe;
    }

    // Getters and Setters

    public function getNom(): ?string {
        return $this->nom;
    }

    public function setNom(?string $nom): void {
        $this->nom = $nom;
    }

    public function getPrenom(): ?string {
        return $this->prenom;
    }

    public function setPrenom(?string $prenom): void {
        $this->prenom = $prenom;
    }

    public function getEmail(): ?string {
        return $this->email;
    }

    public function setEmail(?string $email): void {
        $this->email = $email;
    }

    public function getDateNaissance(): ?DateTime {
        return $this->date_naissance;
    }

    public function setDateNaissance(?DateTime $date_naissance): void {
        $this->date_naissance = $date_naissance;
    }

    public function getLieuNaissance(): ?string {
        return $this->lieu_naissance;
    }

    public function setLieuNaissance(?string $lieu_naissance): void {
        $this->lieu_naissance = $lieu_naissance;
    }

    public function getSexe(): ?string {
        return $this->sexe;
    }

    public function setSexe(?string $sexe): void {
        $this->sexe = $sexe;
    }

    public function getMotDePasse(): ?string {
        return $this->mot_de_passe;
    }

    public function setMotDePasse(?string $mot_de_passe): void {
        $this->mot_de_passe = $mot_de_passe;
    }
}

?>