<?php
include "../config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération et nettoyage des données
    $nom = trim($_POST["nom"]);
    $prenom = trim($_POST["prenom"]);
    $email = trim($_POST["email"]);
    $dateNaissance = $_POST["date_naissance"];
    $lieuNaissance = trim($_POST["lieu_naissance"]);
    $sexe = $_POST["sexe"];
    $password = $_POST["mot_de_passe"];

    // Hachage du mot de passe
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);

    try {
        $pdo = config::getConnexion();
        $stmt = $pdo->prepare("INSERT INTO utilisateurs (nom, prenom, email, date_naissance, lieu_naissance, sexe, mot_de_passe)
                               VALUES (:nom, :prenom, :email, :date_naissance, :lieu_naissance, :sexe, :mot_de_passe)");

        $stmt->bindParam(':nom', $nom);
        $stmt->bindParam(':prenom', $prenom);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':date_naissance', $dateNaissance);
        $stmt->bindParam(':lieu_naissance', $lieuNaissance);
        $stmt->bindParam(':sexe', $sexe);
        $stmt->bindParam(':mot_de_passe', $passwordHash);

        if ($stmt->execute()) {
            echo "<script>alert('Inscription réussie !');</script>";
        } else {
            echo "<script>alert('Erreur lors de l\\'inscription.');</script>";
        }
    } catch (PDOException $e) {
        echo "<script>alert('Erreur : " . $e->getMessage() . "');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un compte</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url("hopital.jpg");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: rgba(255, 255, 255, 0.5); /* Transparence partielle */
            backdrop-filter: blur(5px);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 350px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        h2 {
            text-align: center;
        }
        .banner {
            background-color: #2d88fd; 
            color: white;
            font-weight: bold;
            font-style: italic;
            padding: 15px;
            width: 100%;
            text-align: center;
            margin-bottom: 10px; 
        }
        form {
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        label {
            width: 90%;
            text-align: left;
            margin-top: 10px;
        }
        input, select {
            width: 90%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 90%;
            padding: 10px;
            background: #28a1ae;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #218838;
        }
        .link {
            text-align: center;
            margin-top: 10px;
        }
        .link a {
            text-decoration: none;
            color: #007bff;
        }
        .link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="banner">
            AloDoktor
        </div>

        <h2>Créer un compte</h2>
        <form action="#" method="POST">
            <input type="text" name="nom" placeholder="Nom" >
            <input type="text" name="prenom" placeholder="Prénom" >
            <input type="text" name="email" placeholder="Adresse Email" >
            <label for="date_naissance">Date de naissance</label>
            <input type="date" id="date_naissance" name="date_naissance" >
            <input type="text" name="lieu_naissance" placeholder="Lieu de naissance" >
            <label for="sexe">Genre</label>
            <select id="sexe" name="sexe" >
                <option value="">Sexe</option>
                <option value="homme">Homme</option>
                <option value="femme">Femme</option>
            </select>
            <input type="password" name="mot_de_passe" placeholder="Mot de passe" >
            <button type="submit">S'inscrire</button>
        </form>
        <div class="link">
            <p>Avez-vous déjà un compte? <a href="connecter.php">Connecter</a></p>
        </div>
    </div>
    <script>
        document.querySelector("form").addEventListener("submit", function(event) {
            let nom = document.querySelector("input[name='nom']");
            let prenom = document.querySelector("input[name='prenom']");
            let email = document.querySelector("input[name='email']");
            let dateNaissance = document.querySelector("#date_naissance");
            let lieuNaissance = document.querySelector("input[name='lieu_naissance']");
            let sexe = document.querySelector("#sexe");
            let password = document.querySelector("input[name='mot_de_passe']");
            let isValid = true;
            
            // Vérification des champs obligatoires
            if (!nom.value || !prenom.value || !email.value || !dateNaissance.value || !lieuNaissance.value || !sexe.value || !password.value) {
                alert("Tous les champs doivent être remplis.");
                isValid = false;
            }
        
            // Vérification que nom et prénom contiennent seulement des lettres
            let namePattern = /^[A-Za-zÀ-ÿ\s'-]+$/;
            if (!namePattern.test(nom.value)) {
                alert("Le nom ne doit contenir que des lettres.");
                isValid = false;
            }
            if (!namePattern.test(prenom.value)) {
                alert("Le prénom ne doit contenir que des lettres.");
                isValid = false;
            }
            
            // Vérification de l'email
            let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if (!emailPattern.test(email.value)) {
                alert("Veuillez entrer une adresse email valide.");
                isValid = false;
            }
            
            // Vérification du mot de passe (au moins 8 caractères, sans autres contraintes)
            if (password.value.length < 8) {
                alert("Le mot de passe doit contenir au moins 8 caractères.");
                isValid = false;
            }
            
            // Vérification de l'âge (minimum 18 ans)
            let birthDate = new Date(dateNaissance.value);
            let today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();
            let monthDiff = today.getMonth() - birthDate.getMonth();
            if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            if (age < 18) {
                alert("Vous devez avoir au moins 18 ans pour vous inscrire.");
                isValid = false;
            }
        
            if (!isValid) {
                event.preventDefault(); 
            }
        });
    </script>
</body>
</html>

