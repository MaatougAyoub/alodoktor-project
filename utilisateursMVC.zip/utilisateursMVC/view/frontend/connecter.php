 <?php
session_start();
include '../config.php'; // Assure-toi que le chemin est correct

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    try {
        $pdo = config::getConnexion();
        $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = :email");
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            if (password_verify($password, $user['mot_de_passe'])) {
                $_SESSION['email'] = $user['email'];
                //header("Location: ../backend/utilisateurs_view.php");
                exit();
            } else {
                $error = "Mot de passe incorrect.";
            }
        } else {
            $error = "Adresse email non trouvée.";
        }
    } catch (PDOException $e) {
        $error = "Erreur de connexion : " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url("hopital.jpg");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            margin: 0;
        }

        .login-container {
            background-color: rgba(255, 255, 255, 0.5);
            backdrop-filter: blur(5px);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 350px;
        }

        h2 {
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            text-align: left;
            margin-bottom: 5px;
        }

        input {
            padding: 10px;
            margin-bottom: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .error {
            color: red;
            font-size: 0.9em;
            margin-bottom: 10px;
            text-align: left;
            width: 100%;
        }

        button {
            background: #28a1ae;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background: #218838;
        }

        .register-message {
            margin-top: 15px;
        }

        .register-message a {
            color: #007BFF;
            text-decoration: none;
        }

        .register-message a:hover {
            text-decoration: underline;
        }

        .site-banner {
            background-color: #2d88fd;
            color: white;
            font-weight: bold;
            font-style: italic;
            padding: 15px;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="site-banner">AloDoktor</div>
        <h2>Connexion</h2>
        <form id="loginForm" method="POST" action="">
            <label for="email">Adresse Email</label>
            <input type="text" id="email" name="email" >

            <label for="password">Mot de passe</label>
            <input type="password" id="password" name="password" >

            <?php if (!empty($error)): ?>
                <p class="error"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>

            <button type="submit">Se connecter</button>
        </form>
        <p class="register-message">
            Vous n'avez pas un compte ? <a href="creer_un_compte.php">Créer un compte</a>
        </p>
    </div>
</body>
</html>
