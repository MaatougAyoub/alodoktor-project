 <?php
include '../../controller/utilisateurs_controller.php';

// Vérifier si l'email de l'utilisateur à supprimer est passé en paramètre dans l'URL
if (isset($_GET["email"])) {
    $email = $_GET["email"];

    // Créer une instance du contrôleur des utilisateurs
    $utilisateursController = new utilisateursController();

    // Appeler la méthode pour supprimer l'utilisateur basé sur son email
    $utilisateursController->deleteUtilisateur($email);

    // Rediriger vers la liste des utilisateurs après suppression
    header('Location:lister_utilisateurs.php');
    exit();
} else {
    // Si aucun email n'est passé dans l'URL, rediriger vers la liste des utilisateurs
    header('Location:lister_utilisateurs.php');
    exit();
}
?>
