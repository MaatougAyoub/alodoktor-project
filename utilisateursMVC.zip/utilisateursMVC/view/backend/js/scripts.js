window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.querySelector('#sidebarToggle');
    const sidebar = document.querySelector('#layoutSidenav_nav'); // Sélectionne le sidebar

    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();

            // Toggle la classe d'affichage sur le sidebar
            sidebar.classList.toggle('d-none');

            // Sauvegarde l'état dans localStorage
            const isHidden = sidebar.classList.contains('d-none');
            localStorage.setItem('sb|sidebar-hidden', isHidden);
        });

        // Vérifier l'état du localStorage au chargement de la page
        if (localStorage.getItem('sb|sidebar-hidden') === 'true') {
            sidebar.classList.add('d-none');
        }
    }

});
