 <?php
include '../../controller/utilisateurs_controller.php';

$error = "";
$utilisateur = null;
$utilisateursController = new utilisateursController();

if (
    isset($_POST["nom"], $_POST["prenom"], $_POST["email"], $_POST["date_naissance"], $_POST["lieu_naissance"], $_POST["sexe"])
) {
    if (
        !empty($_POST["nom"]) && !empty($_POST["prenom"]) && !empty($_POST["email"]) &&
        !empty($_POST["date_naissance"]) && !empty($_POST["lieu_naissance"]) && !empty($_POST["sexe"])
    ) {
        if (isset($_POST['email'])) {
            $utilisateur = $utilisateursController->showUtilisateur($_POST['email']);
        }

        if (!empty($_POST['mot_de_passe'])) {
            $mot_de_passe_hash = password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT);
        } else {
            $mot_de_passe_hash = $utilisateur['mot_de_passe'];
        }

        $utilisateur = new Utilisateur(
            $_POST['nom'],
            $_POST['prenom'],
            $_POST['email'],
            new DateTime($_POST['date_naissance']),
            $_POST['lieu_naissance'],
            $_POST['sexe'],
            $mot_de_passe_hash
        );

        $utilisateursController->updateUtilisateur($utilisateur, $_POST['email']);
        header('Location: utilisateurs_view.php');
        exit();
    } else {
        $error = "Des informations sont manquantes.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Modifier Utilisateur</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <style>
        body {
            background:rgb(184, 228, 228);
            font-family: 'Nunito', sans-serif;
        }
        .container-fluid h1 {
            font-weight: 700;
            color: #4e73df;
            text-align: center;
        }
        .card {
            border-radius: 1rem;
        }
        .form-container {
            width: 600px; /* largeur réduite */
            margin: 50px auto; /* centrage horizontal + espace en haut */
            padding: 2rem;
            background-color: rgba(255, 255, 255, 0.9); /* effet léger transparent */
            border-radius: 1rem;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.15);
        }
        .form-control {
            border-radius: 0.5rem;
            transition: all 0.3s ease-in-out;
        }
        .form-control:focus {
            border-color: #4e73df;
            box-shadow: 0 0 5px rgba(78, 115, 223, 0.5);
        }
        label {
            font-weight: 600;
            margin-bottom: 0.3rem;
        }
        .btn-primary {
            background-color: #4e73df;
            border: none;
            border-radius: 0.5rem;
            padding: 10px;
            font-weight: 600;
            transition: background-color 0.3s ease-in-out;
            display: block; /* Permet de centrer */
            margin: 20px auto 0 auto; /* Centre le bouton avec un peu d'espace en haut */
        }
        
        .btn-primary:hover {
            background-color: #2e59d9;
        }
        .alert-danger {
            font-weight: bold;
            border-radius: 0.5rem;
        }
        .form-container .form-group {
            margin-bottom: 1.5rem;
        }
        .form-container .form-row {
            display: flex;
            justify-content: space-between;
        }
        .form-container .form-row .form-group {
            width: 48%;
        }
        .form-container .form-group select, .form-container .form-group input {
            width: 100%;
        }
    </style>
</head>
<body id="page-top">

<div id="wrapper">
    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <div class="container-fluid">
                <h1 class="h3 mb-4 text-gray-800">Modifier Utilisateur</h1>

                <div class="card shadow mb-4">
                    <div class="card-body">
                        <?php if (isset($_GET['email'])):
                            $utilisateur = $utilisateursController->showUtilisateur($_GET['email']);
                        ?>
                        <div class="form-container">
                            <?php if ($error): ?>
                                <div class="alert alert-danger"><?= $error; ?></div>
                            <?php endif; ?>
                            <form id="updateUtilisateurForm" method="POST">
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="nom"><i class="fas fa-user"></i> Nom</label>
                                        <input type="text" class="form-control" id="nom" name="nom" value="<?= $utilisateur['nom'] ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="prenom"><i class="fas fa-user"></i> Prénom</label>
                                        <input type="text" class="form-control" id="prenom" name="prenom" value="<?= $utilisateur['prenom'] ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="email"><i class="fas fa-envelope"></i> Email</label>
                                    <input type="text" class="form-control" id="email" name="email" value="<?= $_GET['email'] ?>">
                                </div>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="date_naissance"><i class="fas fa-calendar"></i> Date de naissance</label>
                                        <input type="date" class="form-control" id="date_naissance" name="date_naissance" value="<?= $utilisateur['date_naissance'] ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="lieu_naissance"><i class="fas fa-map-marker-alt"></i> Lieu de naissance</label>
                                        <input type="text" class="form-control" id="lieu_naissance" name="lieu_naissance" value="<?= $utilisateur['lieu_naissance'] ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="sexe"><i class="fas fa-venus-mars"></i> Sexe</label>
                                    <select class="form-control" id="sexe" name="sexe">
                                        <option value="Homme" <?= ($utilisateur['sexe'] == 'Homme') ? 'selected' : '' ?>>Homme</option>
                                        <option value="Femme" <?= ($utilisateur['sexe'] == 'Femme') ? 'selected' : '' ?>>Femme</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="mot_de_passe"><i class="fas fa-lock"></i> Nouveau mot de passe</label>
                                    <input type="password" class="form-control" id="mot_de_passe" name="mot_de_passe">
                                </div>

                                <button type="submit" class="btn btn-primary btn-block">
                                    <i class="fas fa-save"></i> Enregistrer les modifications
                                </button>
                            </form>

                        </div>
                        <?php else: ?>
                            <p class="text-danger">Utilisateur non trouvé !</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JS de Bootstrap et autres -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="js/sb-admin-2.min.js"></script>

<!-- Script de validation JavaScript -->
<script>
    document.getElementById("updateUtilisateurForm").addEventListener("submit", function(event) {
        let nom = document.getElementById("nom");
        let prenom = document.getElementById("prenom");
        let email = document.getElementById("email");
        let dateNaissance = document.getElementById("date_naissance");
        let lieuNaissance = document.getElementById("lieu_naissance");
        let sexe = document.getElementById("sexe");
        let password = document.getElementById("mot_de_passe");
        let isValid = true;

        if (!nom.value || !prenom.value || !email.value || !dateNaissance.value || !lieuNaissance.value || !sexe.value) {
            alert("Tous les champs obligatoires doivent être remplis.");
            isValid = false;
        }

        let namePattern = /^[A-Za-zÀ-ÿ\s'-]+$/;
        if (!namePattern.test(nom.value)) {
            alert("Le nom ne doit contenir que des lettres.");
            isValid = false;
        }
        if (!namePattern.test(prenom.value)) {
            alert("Le prénom ne doit contenir que des lettres.");
            isValid = false;
        }

        let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailPattern.test(email.value)) {
            alert("Veuillez entrer une adresse email valide.");
            isValid = false;
        }

        if (password.value && password.value.length < 8) {
            alert("Le mot de passe doit contenir au moins 8 caractères.");
            isValid = false;
        }

        let birthDate = new Date(dateNaissance.value);
        let today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        let monthDiff = today.getMonth() - birthDate.getMonth();
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        if (age < 18) {
            alert("L'utilisateur doit avoir au moins 18 ans.");
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault();
        }
    });
</script>
</body>
</html>
