 <?php
include '../../controller/utilisateurs_controller.php';

$error = "";

// Créer une instance du contrôleur
$utilisateurController = new utilisateursController();

// Vérification si les données sont envoyées via POST depuis le formulaire existant
if (
    isset($_POST["nom"]) && isset($_POST["prenom"]) && isset($_POST["email"]) && isset($_POST["date_naissance"]) &&
    isset($_POST["lieu_naissance"]) && isset($_POST["sexe"]) && isset($_POST["mot_de_passe"])
) {
    if (
        !empty($_POST["nom"]) && !empty($_POST["prenom"]) && !empty($_POST["email"]) && !empty($_POST["date_naissance"]) &&
        !empty($_POST["lieu_naissance"]) && !empty($_POST["sexe"]) && !empty($_POST["mot_de_passe"])
    ) {
        $utilisateur = new Utilisateur(
            null, // id is generated automatically
            $_POST['nom'],
            $_POST['prenom'],
            $_POST['email'],
            new DateTime($_POST['date_naissance']),
            $_POST['lieu_naissance'],
            $_POST['sexe'],
            password_hash($_POST['mot_de_passe'], PASSWORD_DEFAULT) // Encrypting password
        );

        // Ajouter l'utilisateur à la base de données
        $utilisateurController->addUtilisateur($utilisateur);

        // Redirection après ajout
        header('Location: utilisateurs_view.php');
        exit();
    } else {
        $error = "Tous les champs doivent être remplis.";
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter un utilisateur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgb(167, 210, 224);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 800px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
        }
        form {
            width: 100%;
            display: flex;
            flex-direction: column;
        }
        input, select {
            width: 90%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 90%;
            padding: 10px;
            background: #28a1ae;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #218838;
        }
        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Ajouter un utilisateur</h2>

        <!-- Affichage des erreurs -->
        <?php if (!empty($error)): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <!-- Formulaire d'ajout -->
        <form action="ajouter_utilisateurs.php" method="POST">
            <input type="text" name="nom" placeholder="Nom" required>
            <input type="text" name="prenom" placeholder="Prénom" required>
            <input type="email" name="email" placeholder="Adresse Email" required>
            <input type="date" name="date_naissance" required>
            <input type="text" name="lieu_naissance" placeholder="Lieu de naissance" required>
            <select name="sexe" required>
                <option value="">Sélectionner Sexe</option>
                <option value="homme">Homme</option>
                <option value="femme">Femme</option>
            </select>
            <input type="password" name="mot_de_passe" placeholder="Mot de passe" required>
            <button type="submit">Ajouter l'utilisateur</button>
        </form>
    </div>
</body>
</html>
