 <?php
// Inclure le fichier config.php pour utiliser la classe Config
//include '../../config.php';
include '../../controller/utilisateurs_controller.php';

// Créer une instance du contrôleur des utilisateurs
$utilisateursController = new utilisateursController();

// Récupérer tous les utilisateurs pour les afficher
$users = $utilisateursController->getAllUtilisateurs();

// Vérifier si une action de suppression a été demandée
if (isset($_POST['supprimer']) && isset($_POST['email'])) {
    $email = htmlspecialchars($_POST['email']);
    // Appeler la méthode de suppression
    $utilisateursController->deleteUtilisateur($email);
    // Rediriger vers la même page après la suppression
    header('Location: utilisateurs_view.php');
    exit();
}

// Vérifier si une action de modification a été demandée
if (isset($_POST['modifier']) && isset($_POST['email'])) {
    $email = htmlspecialchars($_POST['email']);
    // Rediriger vers la page de modification avec l'email de l'utilisateur
    header("Location: ../../view/backend/modifier_utilisateurs.php?email=$email");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet" />
    <title>YY</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: rgb(167, 210, 224);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 800px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #2d88fd;
            color: white;
        }
        .btn {
            padding: 5px 10px;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-delete {
            background-color: red !important;
        }

        .btn-delete:hover {
            background-color: darkred !important;
        }

        .btn-edit {
            background-color: orange !important;
        }

        .btn-edit:hover {
            background-color: darkorange !important;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="index.html"><i class="fa fa-stethoscope"></i>AloDoktor</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <!-- Navbar Search-->
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0">
            <div class="input-group">
                <input class="form-control" type="text" placeholder="Search for..." aria-label="Search for..." aria-describedby="btnNavbarSearch" />
                <button class="btn btn-primary" id="btnNavbarSearch" type="button"><i class="fas fa-search"></i></button>
            </div>
        </form>
        <a class="navbarSignIn" href="#">Se connecter</a>
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <a class="nav-link" href="index.html">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-house"></i></div>
                            Accueil
                        </a>
                        <a class="nav-link" href="#">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-user-plus"></i></div>
                            Inscriptions
                        </a>
                        <a class="nav-link" href="departementsBacks.html">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-hospital"></i></div>
                            Départements
                        </a>
                        <a class="nav-link" href="#">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-hand-holding-dollar"></i></div>
                            Dons
                        </a>
                        <a class="nav-link" href="#">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-flask-vial"></i></div>
                            Analyses
                        </a>
                        <a class="nav-link" href="#">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-prescription-bottle"></i></div>
                            Pharmacie
                        </a>
                        <a class="nav-link" href="#">
                            <div class="sb-nav-link-icon"><i class="fa-solid fa-comments"></i></div>
                            Réclamations
                        </a> 
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>
                    Start Bootstrap
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                <div class="container">
                    <h2>Liste des utilisateurs inscrits</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Prénom</th>
                                <th>Email</th>
                                <th>Date de naissance</th>
                                <th>Lieu de naissance</th>
                                <th>Sexe</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?= htmlspecialchars($user['nom']) ?></td>
                                    <td><?= htmlspecialchars($user['prenom']) ?></td>
                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                    <td><?= htmlspecialchars($user['date_naissance']) ?></td>
                                    <td><?= htmlspecialchars($user['lieu_naissance']) ?></td>
                                    <td><?= htmlspecialchars($user['sexe']) ?></td>
                                    <td>
                                        <!-- Formulaire de modification -->
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="email" value="<?= htmlspecialchars($user['email']) ?>">
                                            <button type="submit" name="modifier" class="btn btn-edit">Modifier</button>
                                        </form>
                                        <!-- Formulaire de suppression -->
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="email" value="<?= htmlspecialchars($user['email']) ?>">
                                            <button type="submit" name="supprimer" class="btn btn-delete">Supprimer</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
    <div class="copyright-page">
        <div class="copyrigt">
            <p class="copyright-page-p">Copyright</p>
            <i class="fa-solid fa-copyright" id="copyright-page-icon"></i>
            <p class="copyright-page-p">AloDoktor 2025</p>
        </div>
        <p class="copyright-page-p">Privacy Policy Legal Notice</p>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="assets/demo/chart-area-demo.js"></script>
    <script src="assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
    <script src="js/datatables-simple-demo.js"></script>
</body>
</html>
