<?php
include(__DIR__ . '/../view/config.php');
include(__DIR__ . '/../model/utilisateurs_model.php');

class utilisateursController
{
    public function getAllUtilisateurs()
    {
        try {
            $db = config::getConnexion();
            $sql = "SELECT * FROM utilisateurs";
            $stmt = $db->query($sql);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            die('Erreur : ' . $e->getMessage());
        }
    }

    public function deleteUtilisateur($email)
    {
        try {
            $db = config::getConnexion();
            $sql = "DELETE FROM utilisateurs WHERE email = :email";
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
        } catch (PDOException $e) {
            die('Erreur : ' . $e->getMessage());
        }
    }

    public function addUtilisateur($utilisateur)
    {
        try {
            $db = config::getConnexion();
            $sql = "INSERT INTO utilisateurs 
                    (nom, prenom, email, date_naissance, lieu_naissance, sexe, mot_de_passe)
                    VALUES (:nom, :prenom, :email, :date_naissance, :lieu_naissance, :sexe, :mot_de_passe)";
            $stmt = $db->prepare($sql);
            $stmt->execute([
                'nom' => $utilisateur->getNom(),
                'prenom' => $utilisateur->getPrenom(),
                'email' => $utilisateur->getEmail(),
                'date_naissance' => $utilisateur->getDateNaissance()->format('Y-m-d'),
                'lieu_naissance' => $utilisateur->getLieuNaissance(),
                'sexe' => $utilisateur->getSexe(),
                'mot_de_passe' => password_hash($utilisateur->getMotDePasse(), PASSWORD_DEFAULT)
            ]);
        } catch (PDOException $e) {
            die('Erreur : ' . $e->getMessage());
        }
    }

    public function updateUtilisateur($utilisateur, $email)
    {
        try {
            $db = config::getConnexion();
            $sql = "UPDATE utilisateurs SET 
                        nom = :nom,
                        prenom = :prenom,
                        date_naissance = :date_naissance,
                        lieu_naissance = :lieu_naissance,
                        sexe = :sexe,
                        mot_de_passe = :mot_de_passe
                    WHERE email = :email";
            $stmt = $db->prepare($sql);
            $stmt->execute([
                'nom' => $utilisateur->getNom(),
                'prenom' => $utilisateur->getPrenom(),
                'date_naissance' => $utilisateur->getDateNaissance()->format('Y-m-d'),
                'lieu_naissance' => $utilisateur->getLieuNaissance(),
                'sexe' => $utilisateur->getSexe(),
                'mot_de_passe' => password_hash($utilisateur->getMotDePasse(), PASSWORD_DEFAULT),
                'email' => $email
            ]);
        } catch (PDOException $e) {
            die('Erreur : ' . $e->getMessage());
        }
    }

    public function showUtilisateur($email)
    {
        try {
            $db = config::getConnexion();
            $sql = "SELECT * FROM utilisateurs WHERE email = :email";
            $stmt = $db->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            return $stmt->fetch();
        } catch (PDOException $e) {
            die('Erreur : ' . $e->getMessage());
        }
    }
}